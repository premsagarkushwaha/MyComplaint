package com.example.mycompalaint;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class resolvedComplaints extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resolved_complaints);
    }
}